package testGrafico;

public class ContoCorrente {
	
	public static Integer saldo=400;
	
	public int deposito(int d) {
		if(d>0) {
		saldo=d+saldo;
		}
		return saldo;
	}
	public int prelievo(int p) {
		if (p<saldo) {
			saldo=saldo-p;
		}
		return saldo;
	}
}
