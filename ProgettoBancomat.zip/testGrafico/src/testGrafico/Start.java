package testGrafico;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		ContoCorrente c= new ContoCorrente();
		MyFrame x=new MyFrame("Login",c);
		
		
		
		
		
		
	}

}
